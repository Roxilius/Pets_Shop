package com.example.server.constants;

public class RolesConstant {
    public static final String ADMIN_ROLE = "ADMIN";
    public static final String USER_ROLE = "USER";
}
